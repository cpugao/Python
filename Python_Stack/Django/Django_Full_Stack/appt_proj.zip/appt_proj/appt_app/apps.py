from django.apps import AppConfig


class ApptAppConfig(AppConfig):
    name = 'appt_app'
