from django.apps import AppConfig


class ShellAppConfig(AppConfig):
    name = 'Shell_App'
