from django.apps import AppConfig


class DjangoAppAssignmentConfig(AppConfig):
    name = 'Django_App_Assignment'
