from django.apps import AppConfig


class GoldAppConfig(AppConfig):
    name = 'Gold_App'
