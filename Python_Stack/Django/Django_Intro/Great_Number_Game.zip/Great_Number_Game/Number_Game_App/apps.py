from django.apps import AppConfig


class NumberGameAppConfig(AppConfig):
    name = 'Number_Game_App'
